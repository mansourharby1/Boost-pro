package com.boosterpro.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppsFragment : Fragment(R.layout.fragment_apps) {

    private var all: List<AppItem> = emptyList()
    private var category: Category? = null
    private var query = ""
    private var sortIndex = 0

    private lateinit var adapter: AppAdapter
    private lateinit var tvCount: TextView
    private lateinit var banner: View
    private lateinit var loading: ProgressBar

    override fun onViewCreated(v: View, savedInstanceState: Bundle?) {
        tvCount = v.findViewById(R.id.tvCount)
        banner = v.findViewById(R.id.banner)
        loading = v.findViewById(R.id.loading)

        adapter = AppAdapter(
            onStop = { Actions.instantStop(requireContext(), it.pkg) },
            onClick = { app -> Actions.showMenu(requireContext(), app) { apply() } }
        )
        val list = v.findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = adapter

        v.findViewById<View>(R.id.btnGrant).setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        v.findViewById<EditText>(R.id.search).doAfterTextChanged {
            query = it?.toString()?.trim().orEmpty()
            apply()
        }

        // Category chips
        val chips = v.findViewById<ChipGroup>(R.id.chips)
        fun addChip(title: String, cat: Category?, checked: Boolean) {
            val chip = layoutInflater.inflate(R.layout.chip_choice, chips, false) as Chip
            chip.text = title
            chip.id = View.generateViewId()
            chip.isChecked = checked
            chip.setOnClickListener {
                category = cat
                apply()
            }
            chips.addView(chip)
        }
        addChip("الكل", null, true)
        for (c in Category.values()) addChip(c.title, c, false)

        // Sort spinner
        val sort = v.findViewById<Spinner>(R.id.sort)
        val sa = ArrayAdapter(
            requireContext(), android.R.layout.simple_spinner_item,
            arrayOf("الرام (تقديري)", "حجم التخزين", "وقت الاستخدام", "الاسم")
        )
        sa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sort.adapter = sa
        sort.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                sortIndex = pos
                apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        val appCtx = requireContext().applicationContext
        banner.visibility = if (AppRepo.hasUsageAccess(appCtx)) View.GONE else View.VISIBLE
        if (all.isEmpty()) loading.visibility = View.VISIBLE
        viewLifecycleOwner.lifecycleScope.launch {
            val result = withContext(Dispatchers.Default) { AppRepo.loadApps(appCtx) }
            all = result
            loading.visibility = View.GONE
            apply()
        }
    }

    private fun apply() {
        var l = all.filter { category == null || it.category == category }
        if (query.isNotEmpty()) l = l.filter { it.label.contains(query, ignoreCase = true) }
        l = when (sortIndex) {
            0 -> l.sortedWith(compareByDescending<AppItem> { it.estRam }.thenByDescending { it.fgMs })
            1 -> l.sortedByDescending { it.storage }
            2 -> l.sortedByDescending { it.fgMs }
            else -> l.sortedBy { it.label.lowercase() }
        }
        adapter.submit(l)
        tvCount.text = "${l.size} تطبيق"
    }
}
