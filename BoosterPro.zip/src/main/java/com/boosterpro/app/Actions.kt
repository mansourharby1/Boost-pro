package com.boosterpro.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

object Actions {

    /** Asks the user to enable the accessibility service when it is off. */
    fun ensureAccessibility(ctx: Context): Boolean {
        if (Automation.isEnabled(ctx)) return true
        AlertDialog.Builder(ctx)
            .setTitle("تفعيل الخدمة التلقائية")
            .setMessage(
                "لتنفيذ «الإيقاف الفوري» و«تنظيف الكاش» تلقائياً، فعّل خدمة Booster Pro من إعدادات إمكانية الوصول.\n\n" +
                        "ملاحظة: في أندرويد 13 فما فوق، إذا كان الخيار باهتاً افتح معلومات تطبيق Booster Pro ← القائمة ⋮ ← «السماح بالإعدادات المقيّدة» ثم ارجع وفعّل الخدمة."
            )
            .setPositiveButton("فتح الإعدادات") { _, _ ->
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("إلغاء", null)
            .show()
        return false
    }

    fun openInfo(ctx: Context, pkg: String) {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
        )
    }

    fun instantStop(ctx: Context, pkg: String) {
        Booster.killOne(ctx, pkg)
        if (Automation.isEnabled(ctx)) {
            Automation.start(ctx, listOf(Task(pkg, Mode.FORCE_STOP)))
        } else {
            Toast.makeText(
                ctx, "اضغط «إيقاف إجباري» — فعّل الخدمة التلقائية ليتم ذلك بدون لمس", Toast.LENGTH_LONG
            ).show()
            openInfo(ctx, pkg)
        }
    }

    fun cleanCache(ctx: Context, pkgs: List<String>) {
        if (pkgs.isEmpty()) {
            Toast.makeText(ctx, "لا توجد تطبيقات للتنظيف", Toast.LENGTH_SHORT).show()
            return
        }
        if (!ensureAccessibility(ctx)) return
        Toast.makeText(ctx, "جاري التنظيف… لا تلمس الشاشة", Toast.LENGTH_LONG).show()
        Automation.start(ctx, pkgs.map { Task(it, Mode.CLEAR_CACHE) })
    }

    fun uninstall(ctx: Context, pkg: String) {
        ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
    }

    fun showMenu(ctx: Context, app: AppItem, onChanged: () -> Unit) {
        val prot = Prefs.protectedSet(ctx).contains(app.pkg)
        val options = arrayOf(
            "⛔  إيقاف فوري",
            "🧹  تنظيف الكاش (تلقائي)",
            if (prot) "🔓  إلغاء الحماية من التسريع" else "🛡  حماية من التسريع",
            "ℹ️  معلومات التطبيق",
            "🗑  حذف التطبيق"
        )
        AlertDialog.Builder(ctx)
            .setTitle(app.label)
            .setItems(options) { _, i ->
                when (i) {
                    0 -> instantStop(ctx, app.pkg)
                    1 -> cleanCache(ctx, listOf(app.pkg))
                    2 -> {
                        val now = Prefs.toggleProtected(ctx, app.pkg)
                        Toast.makeText(
                            ctx, if (now) "تمت الحماية: لن يُغلق عند التسريع" else "أُلغيت الحماية", Toast.LENGTH_SHORT
                        ).show()
                        onChanged()
                    }
                    3 -> openInfo(ctx, app.pkg)
                    4 -> uninstall(ctx, app.pkg)
                }
            }
            .show()
    }
}
