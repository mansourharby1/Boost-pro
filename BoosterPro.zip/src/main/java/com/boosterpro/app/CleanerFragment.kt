package com.boosterpro.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CleanerFragment : Fragment(R.layout.fragment_cleaner) {

    private var apps: List<AppItem> = emptyList()
    private lateinit var tvOwn: TextView
    private lateinit var tvAllCache: TextView
    private lateinit var browsersBox: LinearLayout

    override fun onViewCreated(v: View, savedInstanceState: Bundle?) {
        tvOwn = v.findViewById(R.id.tvOwn)
        tvAllCache = v.findViewById(R.id.tvAllCache)
        browsersBox = v.findViewById(R.id.browsersBox)

        v.findViewById<View>(R.id.btnOwn).setOnClickListener {
            val appCtx = requireContext().applicationContext
            viewLifecycleOwner.lifecycleScope.launch {
                val freed = withContext(Dispatchers.IO) { Booster.cleanOwnCache(appCtx) }
                Toast.makeText(appCtx, "تم تنظيف ${SystemInfo.fmt(freed)}", Toast.LENGTH_SHORT).show()
                refreshOwn()
            }
        }
        v.findViewById<View>(R.id.btnAllCache).setOnClickListener {
            Actions.cleanCache(requireContext(), topCacheApps().map { it.pkg })
        }
        v.findViewById<View>(R.id.btnBrowsers).setOnClickListener {
            Actions.cleanCache(requireContext(), browsers().map { it.pkg })
        }
    }

    override fun onResume() {
        super.onResume()
        refreshOwn()
        load()
    }

    private fun refreshOwn() {
        val ctx = context ?: return
        tvOwn.text = "الحجم الحالي: ${SystemInfo.fmt(Booster.ownCacheSize(ctx))}"
    }

    private fun browsers() = apps.filter { it.category == Category.BROWSERS }

    private fun topCacheApps(): List<AppItem> {
        val ctx = context ?: return emptyList()
        return if (AppRepo.hasUsageAccess(ctx)) {
            apps.filter { it.cache > 512 * 1024 }.sortedByDescending { it.cache }.take(20)
        } else {
            apps.filter { !it.isSystem }.take(20)
        }
    }

    private fun load() {
        val appCtx = requireContext().applicationContext
        viewLifecycleOwner.lifecycleScope.launch {
            val result = withContext(Dispatchers.Default) { AppRepo.loadApps(appCtx) }
            apps = result
            showSummary(AppRepo.hasUsageAccess(appCtx))
            showBrowsers()
        }
    }

    private fun showSummary(usage: Boolean) {
        if (usage) {
            val total = apps.sumOf { it.cache }
            tvAllCache.text = "إجمالي الكاش: ${SystemInfo.fmt(total)} في ${apps.count { it.cache > 0 }} تطبيق"
        } else {
            tvAllCache.text = "فعّل «الوصول إلى الاستخدام» من الرئيسية لعرض حجم الكاش وترتيب التطبيقات"
        }
    }

    private fun showBrowsers() {
        browsersBox.removeAllViews()
        val list = browsers()
        if (list.isEmpty()) {
            val t = TextView(requireContext())
            t.text = "لم يتم العثور على متصفحات"
            t.setPadding(48, 16, 48, 16)
            browsersBox.addView(t)
            return
        }
        val inflater = LayoutInflater.from(requireContext())
        for (b in list) {
            val row = inflater.inflate(R.layout.item_app, browsersBox, false)
            row.findViewById<android.widget.ImageView>(R.id.icon).setImageDrawable(b.icon)
            row.findViewById<TextView>(R.id.tvName).text = b.label
            row.findViewById<TextView>(R.id.tvSub).text =
                if (b.cache > 0) "الكاش: ${SystemInfo.fmt(b.cache)}" else "متصفح"
            row.findViewById<TextView>(R.id.tvRight).text = ""
            val btn = row.findViewById<com.google.android.material.button.MaterialButton>(R.id.btnAction)
            btn.text = "تنظيف"
            btn.setOnClickListener { Actions.cleanCache(requireContext(), listOf(b.pkg)) }
            row.setOnClickListener { Actions.openInfo(requireContext(), b.pkg) }
            browsersBox.addView(row)
        }
    }
}
