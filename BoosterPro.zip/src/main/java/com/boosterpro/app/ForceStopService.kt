package com.boosterpro.app

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ForceStopService : AccessibilityService() {

    private var lastRun = 0L

    private val forceStopTexts = listOf(
        "Force stop", "FORCE STOP", "إيقاف إجباري", "فرض الإيقاف", "إيقاف الإجباري", "فرض الإغلاق", "إيقاف"
    )
    private val okTexts = listOf(
        "OK", "Force stop", "Yes", "موافق", "حسنًا", "حسناً", "حسنا", "إيقاف إجباري", "فرض الإيقاف", "إيقاف", "نعم"
    )
    private val storageTexts = listOf(
        "Storage & cache", "Storage usage", "Storage", "التخزين وذاكرة التخزين المؤقت", "استخدام التخزين", "التخزين"
    )
    private val cacheTexts = listOf(
        "Clear cache", "مسح ذاكرة التخزين المؤقت", "مسح الذاكرة المؤقتة", "مسح الكاش", "حذف ذاكرة التخزين المؤقت"
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        Automation.service = this
    }

    override fun onDestroy() {
        if (Automation.service === this) Automation.service = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val task = Automation.current ?: return
        if (event?.packageName == packageName) return
        val now = SystemClock.uptimeMillis()
        if (now - lastRun < 300) return
        lastRun = now
        val root = rootInActiveWindow ?: return
        when (task.mode) {
            Mode.FORCE_STOP -> forceStop(root)
            Mode.CLEAR_CACHE -> clearCache(root)
        }
    }

    private fun forceStop(root: AccessibilityNodeInfo) {
        if (Automation.step == 0) {
            val btn = Automation.findClickable(root, forceStopTexts, exact = true) ?: return
            if (!btn.isEnabled) {          // the app is not running
                Automation.finish(1)
                return
            }
            btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            Automation.step = 1
        } else {
            val ok = Automation.findClickable(root, okTexts, exact = true) ?: return
            ok.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            Automation.finish(1)
        }
    }

    private fun clearCache(root: AccessibilityNodeInfo) {
        val clear = Automation.findClickable(root, cacheTexts, exact = false)
        if (clear != null) {
            if (clear.isEnabled) clear.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            Automation.finish(if (Automation.step == 0) 1 else 2)
            return
        }
        if (Automation.step == 0) {
            val storage = Automation.findClickable(root, storageTexts, exact = false) ?: return
            storage.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            Automation.step = 1
        }
    }
}
