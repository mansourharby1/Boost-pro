package com.boosterpro.app

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeFragment : Fragment(R.layout.fragment_home) {

    private lateinit var gauge: GaugeView
    private lateinit var tvRam: TextView
    private lateinit var tvStorage: TextView
    private lateinit var pbStorage: ProgressBar
    private lateinit var tvBattery: TextView
    private lateinit var pbBattery: ProgressBar
    private lateinit var tvDevice: TextView
    private lateinit var tvUsage: TextView
    private lateinit var tvAcc: TextView
    private lateinit var btnBoost: MaterialButton

    override fun onViewCreated(v: View, savedInstanceState: Bundle?) {
        gauge = v.findViewById(R.id.gauge)
        tvRam = v.findViewById(R.id.tvRam)
        tvStorage = v.findViewById(R.id.tvStorage)
        pbStorage = v.findViewById(R.id.pbStorage)
        tvBattery = v.findViewById(R.id.tvBattery)
        pbBattery = v.findViewById(R.id.pbBattery)
        tvDevice = v.findViewById(R.id.tvDevice)
        tvUsage = v.findViewById(R.id.tvUsageStatus)
        tvAcc = v.findViewById(R.id.tvAccStatus)
        btnBoost = v.findViewById(R.id.btnBoost)

        btnBoost.setOnClickListener { boost() }
        v.findViewById<View>(R.id.btnUsage).setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        v.findViewById<View>(R.id.btnAcc).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.RESUMED) {
                while (true) {
                    refresh()
                    delay(2000)
                }
            }
        }
    }

    private fun refresh() {
        val ctx = context ?: return
        val ram = SystemInfo.ram(ctx)
        gauge.setProgress(ram.percent)
        tvRam.text = "المستخدم ${SystemInfo.fmt(ram.used)} من ${SystemInfo.fmt(ram.total)}  •  المتاح ${SystemInfo.fmt(ram.avail)}"

        val st = SystemInfo.storage()
        pbStorage.progress = st.percent
        tvStorage.text = "المستخدم ${SystemInfo.fmt(st.used)} من ${SystemInfo.fmt(st.total)}  •  الحر ${SystemInfo.fmt(st.free)}"

        val b = SystemInfo.battery(ctx)
        pbBattery.progress = b.level
        tvBattery.text = "${b.level}%  •  ${b.tempC}°C  •  " + if (b.charging) "قيد الشحن" else "غير موصول بالشاحن"

        tvDevice.text = "${Build.MANUFACTURER} ${Build.MODEL}\n" +
                "أندرويد ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
                "عدد أنوية المعالج: ${Runtime.getRuntime().availableProcessors()}"

        tvUsage.text = if (AppRepo.hasUsageAccess(ctx)) "✔ الوصول إلى الاستخدام: مفعّل" else "✖ الوصول إلى الاستخدام: غير مفعّل"
        tvAcc.text = if (Automation.isEnabled(ctx)) "✔ الخدمة التلقائية: مفعّلة" else "✖ الخدمة التلقائية: غير مفعّلة"
    }

    private fun boost() {
        val appCtx = requireContext().applicationContext
        btnBoost.isEnabled = false
        btnBoost.text = "جاري التسريع…"
        viewLifecycleOwner.lifecycleScope.launch {
            val freed = withContext(Dispatchers.IO) { Booster.boost(appCtx) }
            btnBoost.isEnabled = true
            btnBoost.text = "تسريع الآن"
            Toast.makeText(appCtx, "تم تحرير ${SystemInfo.fmt(freed)} من الرام", Toast.LENGTH_LONG).show()
            refresh()
        }
    }
}
