package com.boosterpro.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityNodeInfo

enum class Mode { FORCE_STOP, CLEAR_CACHE }

data class Task(val pkg: String, val mode: Mode)

/** Runs a queue of tasks inside the system "App info" screen using the accessibility service. */
object Automation {
    private val queue = ArrayDeque<Task>()
    private val handler = Handler(Looper.getMainLooper())
    private var appCtx: Context? = null

    @Volatile var current: Task? = null
    var step = 0
    var startedAt = 0L
    var service: ForceStopService? = null

    fun isEnabled(ctx: Context): Boolean {
        val s = Settings.Secure.getString(
            ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return s.contains(ctx.packageName) && s.contains("ForceStopService")
    }

    fun start(ctx: Context, tasks: List<Task>) {
        appCtx = ctx.applicationContext
        queue.addAll(tasks)
        if (current == null) next()
    }

    private fun next() {
        val ctx = appCtx ?: return
        val t = queue.removeFirstOrNull()
        current = t
        if (t == null) {
            val i = Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            ctx.startActivity(i)
            return
        }
        step = 0
        startedAt = SystemClock.uptimeMillis()
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${t.pkg}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        // Watchdog: skip the task if nothing worked after 9 seconds.
        handler.postDelayed({ if (current === t) finish(1) }, 9000)
    }

    /** Finishes the current task, goes back [backs] screens, then starts the next one. */
    fun finish(backs: Int = 1) {
        current = null
        for (i in 0 until backs) {
            handler.postDelayed({ service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) },
                350L * (i + 1))
        }
        handler.postDelayed({ if (current == null) next() }, 350L * backs + 600)
    }

    // ---------- node helpers ----------

    fun findClickable(root: AccessibilityNodeInfo, texts: List<String>, exact: Boolean): AccessibilityNodeInfo? {
        for (t in texts) {
            val nodes = root.findAccessibilityNodeInfosByText(t) ?: continue
            for (n in nodes) {
                if (exact && !(n.text?.toString()?.trim().equals(t, ignoreCase = true))) continue
                var c: AccessibilityNodeInfo? = n
                var depth = 0
                while (c != null && depth < 5) {
                    if (c.isClickable) return c
                    c = c.parent
                    depth++
                }
            }
        }
        return null
    }
}
