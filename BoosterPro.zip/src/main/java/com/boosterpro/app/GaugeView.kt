package com.boosterpro.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator

class GaugeView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private val d = resources.displayMetrics.density
    private val stroke = 18f * d

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = stroke
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#E3F2FD")
    }
    private val fgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = stroke
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#1565C0")
    }
    private val bigText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0D47A1")
        textAlign = Paint.Align.CENTER
        textSize = 46f * d
        isFakeBoldText = true
    }
    private val smallText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#6B7A90")
        textAlign = Paint.Align.CENTER
        textSize = 14f * d
    }
    private val rect = RectF()
    private var shown = 0f
    private var target = 0
    var label: String = "الرام المستخدمة"

    fun setProgress(p: Int) {
        val t = p.coerceIn(0, 100)
        if (t == target && shown.toInt() == t) return
        target = t
        ValueAnimator.ofFloat(shown, t.toFloat()).apply {
            duration = 600
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                shown = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val size = minOf(width, height).toFloat()
        val pad = stroke
        val left = (width - size) / 2f
        val top = (height - size) / 2f
        rect.set(left + pad, top + pad, left + size - pad, top + size - pad)
        fgPaint.color = if (shown >= 85f) Color.parseColor("#E53935") else Color.parseColor("#1565C0")
        c.drawArc(rect, 135f, 270f, false, bgPaint)
        c.drawArc(rect, 135f, 270f * shown / 100f, false, fgPaint)
        val cx = width / 2f
        val cy = height / 2f
        c.drawText("${shown.toInt()}%", cx, cy + 10f * d, bigText)
        c.drawText(label, cx, cy + 36f * d, smallText)
    }
}
