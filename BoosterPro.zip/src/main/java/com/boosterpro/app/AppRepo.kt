package com.boosterpro.app

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.os.Process
import android.os.storage.StorageManager
import kotlin.math.max
import kotlin.math.min

enum class Category(val title: String) {
    SOCIAL("تواصل اجتماعي"),
    GAMES("ألعاب"),
    MEDIA("وسائط"),
    BROWSERS("متصفحات"),
    TOOLS("أدوات"),
    SYSTEM("نظام"),
    OTHER("أخرى")
}

class AppItem(
    val pkg: String,
    val label: String,
    val icon: Drawable,
    val category: Category,
    val isSystem: Boolean
) {
    var storage = 0L      // app + data (bytes)
    var cache = 0L        // cache (bytes)
    var fgMs = 0L         // foreground time in the last 7 days
    var lastUsed = 0L
    var estRam = 0L       // estimated RAM (bytes)
}

object AppRepo {

    private val browserPkgs = setOf(
        "com.android.chrome", "org.mozilla.firefox", "org.mozilla.firefox_beta",
        "org.mozilla.fenix", "com.microsoft.emmx", "com.opera.browser",
        "com.opera.mini.native", "com.brave.browser", "com.sec.android.app.sbrowser",
        "com.UCMobile.intl", "com.duckduckgo.mobile.android", "com.kiwibrowser.browser",
        "com.vivaldi.browser", "com.android.browser", "mark.via.gp",
        "com.mi.globalbrowser", "com.huawei.browser", "com.heytap.browser",
        "com.google.android.apps.chrome", "org.chromium.chrome", "com.yandex.browser"
    )

    private val socialHints = listOf(
        "whatsapp", "facebook", "instagram", "telegram", "tiktok", "snapchat",
        "twitter", "messenger", "viber", "linkedin", "reddit", "pinterest",
        "discord", "imo", "skype", "signal", "threads"
    )
    private val mediaHints = listOf(
        "youtube", "spotify", "netflix", "music", "video", "player", "gallery",
        "photos", "camera", "anghami", "soundcloud", "vlc", "mxtech", "shahid", "podcast"
    )

    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun categorize(ai: ApplicationInfo, pkg: String): Category {
        val p = pkg.lowercase()
        if (pkg in browserPkgs || p.endsWith(".browser") || p.contains("browser")) return Category.BROWSERS
        when (ai.category) {
            ApplicationInfo.CATEGORY_GAME -> return Category.GAMES
            ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO,
            ApplicationInfo.CATEGORY_IMAGE -> return Category.MEDIA
            ApplicationInfo.CATEGORY_SOCIAL -> return Category.SOCIAL
            ApplicationInfo.CATEGORY_PRODUCTIVITY, ApplicationInfo.CATEGORY_NEWS,
            ApplicationInfo.CATEGORY_MAPS -> return Category.TOOLS
        }
        if (socialHints.any { p.contains(it) }) return Category.SOCIAL
        if (mediaHints.any { p.contains(it) }) return Category.MEDIA
        if (p.contains("game")) return Category.GAMES
        if (Booster.isSystemApp(ai)) return Category.SYSTEM
        if (p.contains("tool") || p.contains("cleaner") || p.contains("file") ||
            p.contains("calculator") || p.contains("calendar") || p.contains("clock")
        ) return Category.TOOLS
        return Category.OTHER
    }

    /** Blocking: call it from a background thread. */
    fun loadApps(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val launchable = pm.queryIntentActivities(launcher, 0).map { it.activityInfo.packageName }.toSet()
        val usageOk = hasUsageAccess(ctx)

        val fg = HashMap<String, Long>()
        val last = HashMap<String, Long>()
        if (usageOk) {
            try {
                val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                val end = System.currentTimeMillis()
                val list = usm.queryUsageStats(
                    UsageStatsManager.INTERVAL_DAILY, end - 7L * 24 * 3600 * 1000, end
                )
                for (u in list ?: emptyList()) {
                    fg[u.packageName] = (fg[u.packageName] ?: 0L) + u.totalTimeInForeground
                    last[u.packageName] = max(last[u.packageName] ?: 0L, u.lastTimeUsed)
                }
            } catch (e: Exception) {
            }
        }

        val ssm = ctx.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        val items = ArrayList<AppItem>()
        for (ai in pm.getInstalledApplications(0)) {
            val p = ai.packageName
            if (p !in launchable || p == ctx.packageName) continue
            val item = AppItem(
                p,
                ai.loadLabel(pm).toString(),
                ai.loadIcon(pm),
                categorize(ai, p),
                Booster.isSystemApp(ai)
            )
            item.fgMs = fg[p] ?: 0L
            item.lastUsed = last[p] ?: 0L
            if (usageOk) {
                try {
                    val s = ssm.queryStatsForPackage(
                        StorageManager.UUID_DEFAULT, p, Process.myUserHandle()
                    )
                    item.storage = s.appBytes + s.dataBytes
                    item.cache = s.cacheBytes
                } catch (e: Exception) {
                }
            }
            items.add(item)
        }
        estimateRam(ctx, items, usageOk)
        return items
    }

    /**
     * Android does not let normal apps read other apps' real RAM usage.
     * So this is only an ESTIMATE: the used RAM is split between apps that were used
     * in the last 12 hours, weighted by how much they were used.
     */
    private fun estimateRam(ctx: Context, items: List<AppItem>, usageOk: Boolean) {
        if (!usageOk) return
        val now = System.currentTimeMillis()
        val recent = items.filter { !it.isSystem && now - it.lastUsed < 12L * 3600 * 1000 }
        if (recent.isEmpty()) return
        val pool = SystemInfo.ram(ctx).used * 0.55
        val weights = recent.associateWith { 1.0 + min(it.fgMs / 3600000.0, 10.0) }
        val sum = weights.values.sum()
        for ((app, w) in weights) {
            app.estRam = min((pool * w / sum).toLong(), 700L * 1024 * 1024)
        }
    }
}
