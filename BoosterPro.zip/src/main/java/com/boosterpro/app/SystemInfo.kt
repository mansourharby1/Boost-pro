package com.boosterpro.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import java.util.Locale

object SystemInfo {

    class Ram(val total: Long, val avail: Long) {
        val used: Long get() = total - avail
        val percent: Int get() = if (total == 0L) 0 else (used * 100 / total).toInt()
    }

    class Storage(val total: Long, val free: Long) {
        val used: Long get() = total - free
        val percent: Int get() = if (total == 0L) 0 else (used * 100 / total).toInt()
    }

    class Battery(val level: Int, val tempC: Float, val charging: Boolean)

    fun ram(ctx: Context): Ram {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return Ram(mi.totalMem, mi.availMem)
    }

    fun storage(): Storage {
        val s = StatFs(Environment.getDataDirectory().path)
        return Storage(s.totalBytes, s.availableBytes)
    }

    fun battery(ctx: Context): Battery {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
        return Battery(if (scale == 0) 0 else level * 100 / scale, temp, charging)
    }

    fun fmt(b: Long): String {
        if (b < 1024) return "$b B"
        val kb = b / 1024.0
        if (kb < 1024) return String.format(Locale.US, "%.0f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb)
        return String.format(Locale.US, "%.2f GB", mb / 1024.0)
    }

    fun fmtTime(ms: Long): String {
        val m = ms / 60000
        return if (m >= 60) "${m / 60} س ${m % 60} د" else "$m د"
    }
}
