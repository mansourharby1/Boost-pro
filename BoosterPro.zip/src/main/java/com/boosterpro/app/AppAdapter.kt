package com.boosterpro.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val onStop: (AppItem) -> Unit,
    private val onClick: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppItem> = emptyList()

    fun submit(list: List<AppItem>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val name: TextView = v.findViewById(R.id.tvName)
        val sub: TextView = v.findViewById(R.id.tvSub)
        val right: TextView = v.findViewById(R.id.tvRight)
        val stop: View = v.findViewById(R.id.btnAction)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val a = items[position]
        h.icon.setImageDrawable(a.icon)
        h.name.text = a.label
        val parts = ArrayList<String>()
        parts.add(a.category.title)
        if (a.storage > 0) parts.add(SystemInfo.fmt(a.storage))
        if (a.fgMs > 0) parts.add("استخدام: " + SystemInfo.fmtTime(a.fgMs))
        h.sub.text = parts.joinToString(" • ")
        h.right.text = if (a.estRam > 0) "~" + SystemInfo.fmt(a.estRam) else ""
        h.stop.setOnClickListener { onStop(a) }
        h.itemView.setOnClickListener { onClick(a) }
    }
}
