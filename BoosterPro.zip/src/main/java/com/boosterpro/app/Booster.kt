package com.boosterpro.app

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.provider.Settings
import java.io.File

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("booster", Context.MODE_PRIVATE)

    fun protectedSet(c: Context): Set<String> =
        sp(c).getStringSet("prot", emptySet()) ?: emptySet()

    /** Returns true if the package is protected after the toggle. */
    fun toggleProtected(c: Context, pkg: String): Boolean {
        val s = HashSet(protectedSet(c))
        val now = if (s.contains(pkg)) {
            s.remove(pkg)
            false
        } else {
            s.add(pkg)
            true
        }
        sp(c).edit().putStringSet("prot", s).apply()
        return now
    }
}

object Booster {

    fun isSystemApp(ai: ApplicationInfo): Boolean =
        (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0

    /** Apps that must never be killed: keyboard and home launcher. */
    private fun essential(ctx: Context): Set<String> {
        val out = HashSet<String>()
        val ime = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        ComponentName.unflattenFromString(ime ?: "")?.packageName?.let { out.add(it) }
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        ctx.packageManager.resolveActivity(home, 0)?.activityInfo?.packageName?.let { out.add(it) }
        return out
    }

    fun killOne(ctx: Context, pkg: String) {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        am.killBackgroundProcesses(pkg)
    }

    /** Stops background processes of all user apps. Returns the RAM freed in bytes. */
    fun boost(ctx: Context): Long {
        val before = SystemInfo.ram(ctx).avail
        val protectedApps = Prefs.protectedSet(ctx)
        val keep = essential(ctx)
        for (ai in ctx.packageManager.getInstalledApplications(0)) {
            val p = ai.packageName
            if (p == ctx.packageName || p in protectedApps || p in keep) continue
            if (isSystemApp(ai)) continue
            killOne(ctx, p)
        }
        cleanOwnCache(ctx)
        Thread.sleep(800)
        return (SystemInfo.ram(ctx).avail - before).coerceAtLeast(0L)
    }

    fun ownCacheSize(ctx: Context): Long =
        dirSize(ctx.cacheDir) + dirSize(ctx.externalCacheDir) + dirSize(ctx.codeCacheDir)

    fun cleanOwnCache(ctx: Context): Long {
        val before = ownCacheSize(ctx)
        clearDir(ctx.cacheDir)
        clearDir(ctx.externalCacheDir)
        clearDir(ctx.codeCacheDir)
        return before
    }

    private fun dirSize(f: File?): Long {
        if (f == null || !f.exists()) return 0L
        if (f.isFile) return f.length()
        var s = 0L
        f.listFiles()?.forEach { s += dirSize(it) }
        return s
    }

    private fun clearDir(f: File?) {
        f?.listFiles()?.forEach { it.deleteRecursively() }
    }
}
