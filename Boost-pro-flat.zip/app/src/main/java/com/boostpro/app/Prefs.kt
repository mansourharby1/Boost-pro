package com.boostpro.app

import android.content.Context
import java.security.MessageDigest

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("boost", Context.MODE_PRIVATE)

    fun lockedApps(c: Context): Set<String> =
        sp(c).getStringSet("locked", emptySet()) ?: emptySet()

    fun setLocked(c: Context, pkg: String, on: Boolean) {
        val s = lockedApps(c).toMutableSet()
        if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putStringSet("locked", s).apply()
    }

    private fun hash(p: String) =
        MessageDigest.getInstance("SHA-256").digest(p.toByteArray()).joinToString("") { "%02x".format(it) }

    fun hasPin(c: Context) = sp(c).getString("pin", null) != null
    fun setPin(c: Context, p: String) = sp(c).edit().putString("pin", hash(p)).apply()
    fun checkPin(c: Context, p: String) = sp(c).getString("pin", null) == hash(p)

    fun iconIndex(c: Context) = sp(c).getInt("icon", 0)
    fun setIconIndex(c: Context, i: Int) = sp(c).edit().putInt("icon", i).apply()
}
