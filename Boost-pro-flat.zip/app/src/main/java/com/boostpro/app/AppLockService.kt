package com.boostpro.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppLockService : AccessibilityService() {

    companion object {
        @Volatile var unlocked: String? = null
    }

    private val ignore = listOf("com.android.systemui", "inputmethod", "keyboard")

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || ignore.any { pkg.contains(it) }) return

        if (pkg != unlocked) unlocked = null
        if (pkg in Prefs.lockedApps(this) && unlocked != pkg) {
            startActivity(
                Intent(this, LockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra("pkg", pkg)
            )
        }
    }

    override fun onInterrupt() {}
}
