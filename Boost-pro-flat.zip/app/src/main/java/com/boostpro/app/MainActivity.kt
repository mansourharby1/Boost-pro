package com.boostpro.app

import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.boostpro.app.databinding.ActivityMainBinding
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val aliases = listOf("IconGreen", "IconBlue", "IconRed")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBoost.setOnClickListener {
            val before = Booster.memInfo(this).availMem
            val n = Booster.boost(this)
            b.root.postDelayed({
                refresh()
                val gained = (Booster.memInfo(this).availMem - before) / 1048576
                toast("اتبعت أمر الإيقاف لـ $n تطبيق • الرام المتاحة زادت حوالي ${maxOf(gained, 0)} ميجا")
            }, 1000)
        }
        b.btnCache.setOnClickListener {
            toast("اتمسح ${Booster.clearOwnCache(this) / 1024} كيلوبايت")
        }
        b.btnApps.setOnClickListener { startActivity(Intent(this, AppListActivity::class.java)) }
        b.btnAccess.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        b.btnPin.setOnClickListener { askPin() }
        b.btnIcon.setOnClickListener { nextIcon() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val mi = Booster.memInfo(this)
        val total = mi.totalMem / 1048576
        val used = total - mi.availMem / 1048576
        b.tvRam.text = "الرام: $used / $total ميجا"
        b.pbRam.progress = (used * 100 / total).toInt()

        val st = StatFs(Environment.getDataDirectory().path)
        b.tvStorage.text = String.format(Locale.US, "التخزين: متاح %.1f من %.1f جيجا",
            st.availableBytes / 1073741824.0, st.totalBytes / 1073741824.0)

        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = (bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1) * 100 /
            (bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100)
        val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        b.tvBattery.text = String.format(Locale.US, "البطارية: %d%% • الحرارة %.1f°C", lvl, temp)

        val cores = Runtime.getRuntime().availableProcessors()
        val freqs = (0 until cores).mapNotNull { Booster.cpuFreqMhz(it) }
        b.tvCpu.text = "المعالج: ${Build.HARDWARE} • $cores أنوية" +
            if (freqs.isNotEmpty()) " • أعلى تردد حالي ${freqs.max()} MHz" else ""
    }

    private fun askPin() {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "PIN جديد (٤ أرقام على الأقل)"
        }
        AlertDialog.Builder(this).setTitle("تغيير الـ PIN").setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                val p = et.text.toString()
                if (p.length >= 4) { Prefs.setPin(this, p); toast("اتحفظ") } else toast("PIN قصير")
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun nextIcon() {
        val next = (Prefs.iconIndex(this) + 1) % aliases.size
        aliases.forEachIndexed { i, name ->
            packageManager.setComponentEnabledSetting(
                ComponentName(packageName, "$packageName.$name"),
                if (i == next) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        }
        Prefs.setIconIndex(this, next)
        toast("الأيقونة اتغيرت — ممكن تاخد ثواني تظهر في اللانشر")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
