package com.boostpro.app

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import java.io.File

object Booster {
    fun memInfo(c: Context): ActivityManager.MemoryInfo {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    }

    /** بيقفل عمليات الخلفية لكل التطبيقات اللي مش تطبيقات نظام. بيرجع عدد التطبيقات اللي اتبعتلها الأمر. */
    fun boost(c: Context): Int {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        var n = 0
        c.packageManager.getInstalledApplications(0).forEach { app ->
            val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (!isSystem && app.packageName != c.packageName) {
                am.killBackgroundProcesses(app.packageName)
                n++
            }
        }
        return n
    }

    fun kill(c: Context, pkg: String) {
        (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(pkg)
    }

    /** بيمسح كاش البرنامج ده بس (أندرويد مش بيسمح بمسح كاش تطبيقات تانية). */
    fun clearOwnCache(c: Context): Long {
        var freed = 0L
        listOfNotNull(c.cacheDir, c.externalCacheDir).forEach { dir ->
            freed += size(dir)
            dir.listFiles()?.forEach { it.deleteRecursively() }
        }
        return freed
    }

    private fun size(f: File): Long =
        if (f.isFile) f.length() else (f.listFiles()?.sumOf { size(it) } ?: 0L)

    fun cpuFreqMhz(core: Int): Int? = try {
        File("/sys/devices/system/cpu/cpu$core/cpufreq/scaling_cur_freq")
            .readText().trim().toInt() / 1000
    } catch (e: Exception) { null }
}
