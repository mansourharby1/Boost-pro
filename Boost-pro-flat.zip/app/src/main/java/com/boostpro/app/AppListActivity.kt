package com.boostpro.app

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class AppListActivity : AppCompatActivity() {

    data class Item(val label: String, val pkg: String, val icon: Drawable)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "قفل / إيقاف التطبيقات"
        val lv = ListView(this)
        setContentView(lv)

        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val items = pm.queryIntentActivities(launcher, 0)
            .map { Item(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }

        lv.adapter = object : ArrayAdapter<Item>(this, 0, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = convertView ?: layoutInflater.inflate(R.layout.item_app, parent, false)
                val item = getItem(position)!!
                v.findViewById<ImageView>(R.id.icon).setImageDrawable(item.icon)
                v.findViewById<TextView>(R.id.name).text = item.label
                val sw = v.findViewById<SwitchCompat>(R.id.sw)
                sw.setOnCheckedChangeListener(null)
                sw.isChecked = item.pkg in Prefs.lockedApps(context)
                sw.setOnCheckedChangeListener { _, on -> Prefs.setLocked(context, item.pkg, on) }
                v.findViewById<Button>(R.id.kill).setOnClickListener {
                    Booster.kill(context, item.pkg)
                    Toast.makeText(context, "تم إيقاف ${item.label}", Toast.LENGTH_SHORT).show()
                }
                return v
            }
        }
    }
}
