package com.boostpro.app

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class LockActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val target = intent.getStringExtra("pkg") ?: ""

        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = if (Prefs.hasPin(this@LockActivity)) "ادخل الـ PIN" else "اختار PIN جديد (٤ أرقام على الأقل)"
            gravity = Gravity.CENTER
        }
        val btn = Button(this).apply { text = "تأكيد" }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(64, 240, 64, 64)
            addView(et); addView(btn)
        })

        btn.setOnClickListener {
            val p = et.text.toString()
            if (!Prefs.hasPin(this)) {
                if (p.length >= 4) { Prefs.setPin(this, p); AppLockService.unlocked = target; finish() }
                else toast("PIN قصير")
            } else if (Prefs.checkPin(this, p)) {
                AppLockService.unlocked = target
                finish()
            } else {
                toast("PIN غلط"); et.text.clear()
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { goHome() }
        })
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
